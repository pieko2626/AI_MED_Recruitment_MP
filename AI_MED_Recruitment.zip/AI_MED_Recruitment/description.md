Author: Maciej Piekoszewski, Informatyka Geoprzestrzenna 1 stopień 2 rok.

**Cardiomegaly Prediction Model**

# 1. Solution Description

This project implements a **Logistic Regression model from scratch** (in the `Logistic_Regression` class) using Python to predict the occurrence of cardiomegaly based on the provided dataset.

The entire solution was written with a focus on correct Machine Learning practices, especially in the context of working with a small dataset.

# 2. Methodology

The main steps of the algorithm are as follows:

1.  **Data Loading:** Data is loaded from a CSV file using the `pandas` library. The script correctly handles non-standard decimal separators (commas instead of periods) by using the `decimal=','` parameter.
2.  **Preprocessing (Standardization):** All input features are **standardized** using `StandardScaler` from `scikit-learn`. This is a crucial step that normalizes the value range of the features, ensuring the stability and faster convergence of our custom gradient descent algorithm.
3.  **Model Implementation:**
    * The `Logistic_Regression` model was written from scratch using `numpy`.
    * The `.fit()` method implements **gradient descent** to find the optimal `weights` and `bias`.
    * The `.predict_probability()` method uses the sigmoid function to return probabilities, and `.final_predict()` applies a 0.5 threshold for the final classification.

# 3. Results Evaluation

Due to the very small size of the dataset, a single `train_test_split` is statistically unreliable so it wasn't used.

To provide a robust evaluation of the model, this solution implements **5-fold Stratified Cross-Validation** (`StratifiedKFold`):

1.  **Validation Loop:** The data is split into 5 "folds." The loop iterates 5 times, each time training the model on 4 folds (approx. 32 samples) and testing on 1 "held-out" fold (approx. 8 samples).
2.  **Preventing Data Leakage:** The `StandardScaler` is correctly fitted (`.fit_transform()`) **only** on the training set within each loop, and then used to transform (`.transform()`) the validation set.
3.  **Presenting Results:**
    * **Results Table:** After the loop, predictions from all 5 folds are collected. A **single, aggregated `classification_report`** is generated from these, representing the model's overall performance on all data.
    * **ROC Curve:** Similarly, the probabilities from all 5 folds are collected to generate a **single, aggregated ROC curve** and calculate the **AUC**, providing the most reliable visual assessment of the model.

# 4. Important

**The program will ask you to enter the full file path!!**